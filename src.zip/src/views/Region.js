import { Col, Row } from "reactstrap";
import SalesChart from "../components/dashboard/SalesChart";
import Region from "../components/dashboard/Region";
import Blog from "../components/dashboard/Blog";




const aCountry = () => {
  return (
    <div>
      <Row>
        
          <Region />
        
      </Row>
    </div>
  );
};

export default aCountry;
