import { Col, Row } from "reactstrap";
import SalesChart from "../components/dashboard/SalesChart";
import Country from "../components/dashboard/Country";
import Blog from "../components/dashboard/Blog";




const aCountry = () => {
  return (
    <div>
      <Row>
        
          <Country />
        
      </Row>
    </div>
  );
};

export default aCountry;
